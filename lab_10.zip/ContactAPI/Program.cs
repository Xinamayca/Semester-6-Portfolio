using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<ContactDb>(opt => opt.UseInMemoryDatabase("ContactList"));

var app = builder.Build();

// GET all contacts
app.MapGet("/contacts", async (ContactDb db) =>
    await db.Contacts.ToListAsync());

// GET a specific contact by ID
app.MapGet("/contacts/{id}", async (int id, ContactDb db) =>
    await db.Contacts.FindAsync(id)
        is { } contact
            ? Results.Ok(contact)
            : Results.NotFound());

// POST - create a new contact
app.MapPost("/contacts", async (Contact contact, ContactDb db) =>
{
    db.Contacts.Add(contact);
    await db.SaveChangesAsync();
    return Results.Created($"/contacts/{contact.Id}", contact);
});

// PUT - update an existing contact
app.MapPut("/contacts/{id}", async (int id, Contact inputContact, ContactDb db) =>
{
    var contact = await db.Contacts.FindAsync(id);
    if (contact is null) return Results.NotFound();

    contact.FirstName = inputContact.FirstName;
    contact.LastName = inputContact.LastName;
    contact.Email = inputContact.Email;
    contact.Phone = inputContact.Phone;

    await db.SaveChangesAsync();
    return Results.Ok(contact);
});

// DELETE - remove a contact
app.MapDelete("/contacts/{id}", async (int id, ContactDb db) =>
{
    if (await db.Contacts.FindAsync(id) is { } contact)
    {
        db.Contacts.Remove(contact);
        await db.SaveChangesAsync();
        return Results.Ok(contact);
    }
    return Results.NotFound();
});

app.Run();
