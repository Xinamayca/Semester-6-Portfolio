# ContactAPI

A simple Web API for Contact Management built with ASP.NET Core Minimal API and Entity Framework Core. Data is stored in memory only and resets when the app restarts.

---

## Setup

### Requirements
- [.NET 8 SDK](https://dotnet.microsoft.com/download)

### Run the project

```bash
dotnet run
```

The API will start at `http://localhost:5000` by default.

---

## Endpoints

### Get all contacts
```
GET /contacts
```
Returns a list of all contacts.

---

### Get a specific contact
```
GET /contacts/{id}
```
Returns the contact with the given ID. Returns 404 if not found.

---

### Create a new contact
```
POST /contacts
```
**Request body (JSON):**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phone": "0612345678"
}
```
Returns the created contact with its assigned ID.

---

### Update a contact
```
PUT /contacts/{id}
```
**Request body (JSON):**
```json
{
  "firstName": "Jane",
  "lastName": "Doe",
  "email": "jane@example.com",
  "phone": "0698765432"
}
```
Returns the updated contact. Returns 404 if not found.

---

### Delete a contact
```
DELETE /contacts/{id}
```
Deletes the contact with the given ID. Returns 404 if not found.

---

## Testing

You can test the API using:
- [Postman](https://www.postman.com/)
- [curl](https://curl.se/)
- Any browser (for GET requests)

**Example curl to create a contact:**
```bash
curl -X POST http://localhost:5000/contacts \
  -H "Content-Type: application/json" \
  -d '{"firstName":"John","lastName":"Doe","email":"john@example.com","phone":"0612345678"}'
```
