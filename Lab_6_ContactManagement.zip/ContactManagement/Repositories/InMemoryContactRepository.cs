using ContactManagement.Models;

namespace ContactManagement.Repositories;

public class InMemoryContactRepository : IContactRepository
{
    private readonly List<Contact> _contacts = new();
    private int _nextId = 1;

    public IEnumerable<Contact> GetAll() => _contacts;

    public Contact? GetById(int id) => _contacts.FirstOrDefault(c => c.Id == id);

    public Contact Create(Contact contact)
    {
        contact.Id = _nextId++;
        _contacts.Add(contact);
        return contact;
    }

    public bool Update(int id, Contact updated)
    {
        var existing = GetById(id);
        if (existing is null) return false;

        existing.Name = updated.Name;
        existing.Email = updated.Email;
        existing.Phone = updated.Phone;
        return true;
    }

    public bool Delete(int id)
    {
        var existing = GetById(id);
        if (existing is null) return false;

        _contacts.Remove(existing);
        return true;
    }
}