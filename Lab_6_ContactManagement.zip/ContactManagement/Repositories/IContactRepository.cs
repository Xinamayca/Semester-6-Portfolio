using ContactManagement.Models;

namespace ContactManagement.Repositories;

public interface IContactRepository
{
    IEnumerable<Contact> GetAll();
    Contact? GetById(int id);
    Contact Create(Contact contact);
    bool Update(int id, Contact contact);
    bool Delete(int id);
}