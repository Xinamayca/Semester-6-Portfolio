using ContactManagement.Models;
using ContactManagement.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace ContactManagement.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ContactsController : ControllerBase
{
    private readonly IContactRepository _repository;

    public ContactsController(IContactRepository repository)
    {
        _repository = repository;
    }

    // GET api/contacts
    [HttpGet]
    public ActionResult<IEnumerable<Contact>> GetAll()
    {
        return Ok(_repository.GetAll());
    }

    // GET api/contacts/5
    [HttpGet("{id:int}")]
    public ActionResult<Contact> GetById(int id)
    {
        var contact = _repository.GetById(id);
        return contact is null ? NotFound() : Ok(contact);
    }

    // POST api/contacts
    [HttpPost]
    public ActionResult<Contact> Create([FromBody] Contact contact)
    {
        if (string.IsNullOrWhiteSpace(contact.Name))
            return BadRequest("Name is required.");

        var created = _repository.Create(contact);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    // PUT api/contacts/5
    [HttpPut("{id:int}")]
    public IActionResult Update(int id, [FromBody] Contact contact)
    {
        return _repository.Update(id, contact) ? NoContent() : NotFound();
    }

    // DELETE api/contacts/5
    [HttpDelete("{id:int}")]
    public IActionResult Delete(int id)
    {
        return _repository.Delete(id) ? NoContent() : NotFound();
    }
}